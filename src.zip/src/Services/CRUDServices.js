import axios from "axios"

//for getting all items by url ====================================>>>>
export const getAllItems = (serviceURL) => {
    return axios.get(serviceURL)
}

//for deleting entry by Id ========================================>>>>
export const deleteItemById = (serviceURL, id) => {
    return axios.delete(serviceURL + "/" + id)

}

//for adding new entry into json ==================================>>>>
export const addNewItem = (serviceURL, data) => {
    return axios.post(serviceURL, data)
}

//for Fetching entry by Id ========================================>>>>
export const getItemById = (serviceURL, id) => {
    return axios.get(serviceURL + "/" + id)
}

//for Update all entry by Id ========================================>>>>
export const setItemById = (serviceURL, id, data) => {
    return axios.put(serviceURL + "/" + id, data)
}


//update single field
export const updateItemById = (serviceURL, id, newProp) => {
    return axios.patch(serviceURL + "/" + id, newProp, { headers: { 'Content-type': 'application/json; charset=UTF-8' } })

}

//for filtering ================================================>>>>
export const getItemsByFilter = (serviceURL, filter, value) => {
    return axios.get(serviceURL + "?" + filter + "=" + value)
}

//filter with two values
export const getItemsByTwoFilter = (serviceURL, filter1, value1, filter2, value2) => {
    return axios.get(serviceURL + "?" + filter1 + "=" + value1 + "&" + filter2 + "=" + value2)
}
