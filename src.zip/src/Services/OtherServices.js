export const constructNewObj = (product, customerId) => {
    let newObj = {
        productId: product.id,
        customerId: customerId,
        productName: product.productName,
        imageUrl: product.imageUrl,
        MRP: product.MRP,
        price: product.price,
        offer: product.offer
    }
    return newObj
}