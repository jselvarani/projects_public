import { getUser } from "./UserService"

export const checkValidUser = async (username, password) => {

    return await getUser(username, password)
        .then(res => res.data[0])

}


export const setAuthentication = () => {
    sessionStorage.setItem('isLoggedIn', true)
}
export const clearAuthentication = () => {
    sessionStorage.clear()
}

export const getValidAuthentication = () => {
    return sessionStorage.getItem('isLoggedIn')
}
