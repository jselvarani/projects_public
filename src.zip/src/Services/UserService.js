import axios from "axios"
import { LOGINJSONURL } from "../Shared/Constants"

export const getUser = (username, password) => {

    const fetchURL = `${LOGINJSONURL}?username=${username}&password=${password}`
    return axios.get(fetchURL)
}
