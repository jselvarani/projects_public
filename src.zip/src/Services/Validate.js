export const validate = (name, password) => {
    let errors = {}
    console.log(name.password)
    if (!name) {
        errors.name = "Name Required"
    } else if (name.length < 4) {
        errors.name = "Name must be more then 4 characters"

    }
    if (!password) {
        errors.password = "Password Required"
    } else if (password.length < 4) {
        errors.password = "Password must be more then 4 characters"

    }

    return errors;

}

export const validateAddress = (address) => {
    let errors = {}
    let validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    if (!address.name) {
        errors.name = "* Name Required"
    } else if (address.name.length < 3)
        errors.name = '* Name should have minimum 3 characters'

    if (!address.phone) {
        errors.phone = "* Phone Number Required"
    } else if (address.phone.length < 10)
        errors.phone = '* Minimum of 10 Characters required '
    if (!address.email) {
        errors.email = "* Email Required"
    }
    else if (!address.email.match(validRegex)) {
        errors.email = "* invalid email format"
    }
    if (!address.street) {
        errors.street = "* Street Required"
    } else if (address.street.length < 3)
        errors.street = "* Minimum 3 characters required"
    if (!address.city) {
        errors.city = "* City Required"
    } else if (address.city.length < 3)
        errors.city = "* Minimum 3 characters required"
    if (!address.state) {
        errors.state = "* State Required"
    } else if (address.state.length < 3)
        errors.state = "* Minimum 3 characters required"
    if (!address.pincode) {
        errors.pincode = "* Pincode Required"
    } else if (address.pincode.length < 6)
        errors.pincode = "* Minimum 6 characters required"
    return errors

}
