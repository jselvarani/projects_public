import moment from "moment/moment"

//to get Today Date
export const getToday = () => {
    return (moment().format('YYYY-MM-DD'))
}