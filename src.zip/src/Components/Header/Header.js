import React, { useEffect, useState } from 'react'
import { AiTwotoneHeart } from 'react-icons/ai'
import { FiShoppingBag, FiUser } from 'react-icons/fi'
import { GiLargeDress } from 'react-icons/gi'
import { BsSearch } from 'react-icons/bs'
import styled from 'styled-components'
import { btnStyles, cursorPointer, textStyles } from '../../Shared/ReusableStyles'
import { useAuth } from '../ContextAPI/AuthContext'
import { clearAuthentication, getValidAuthentication } from '../../Services/LoginLogics'
import { NavLink, useNavigate, redirect } from 'react-router-dom'
import { getAllItems } from '../../Services/CRUDServices'
import { CATEGORYJSONURL } from '../../Shared/Constants'
import { toast } from 'react-toastify'

export default function Header() {
    const { authUser, setAuthUser, isLoggedIn, setIsLoggedIn, setUserInfo } = useAuth()
    const [searchText, setSearchText] = useState('')
    const [categories, setCategories] = useState([])
    const navigate = useNavigate()
    const navLinkStyles = ({ isActive }) => {
        return {
            fontWeight: isActive ? 'bold' : 'normal',
            textDecoration: isActive ? 'none' : 'none'

        }
    }

    useEffect(() => {
        const isLoggedIn = getValidAuthentication();
        getAllCategory()
    }, [])

    const getAllCategory = () => {
        getAllItems(CATEGORYJSONURL)
            .then(res => setCategories(res.data))
            .catch(err => console.log(err))
    }

    const logoutClick = () => {
        setAuthUser({})
        clearAuthentication()
        navigate('/login')

    }

    const search = () => {
        if (searchText.length === 0) {
            navigate('products/?viewAll=all')
            return;
        }
        navigate('products/?search=' + searchText)
    }
    return (
        <Section>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand h1 fw-bold home" onClick={() => navigate('/')}><span className='h3'><GiLargeDress className='text-pink' /></span><span className=''>Selvaas Fashion</span></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            {
                                authUser === undefined ? <li className='nav-item mt-2 pe-auto nav-login'><a className="fw-bold my-auto text-decoration-none text-pink pe-auto"
                                    onClick={() => navigate('../login')}>Login</a></li>
                                    :
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            {authUser.username}
                                        </a>
                                        <ul class="profile dropdown-menu" aria-labelledby="navbarDropdown">
                                            <li className='submenu mt-2'><NavLink style={navLinkStyles} className="submenu text-grey ps-3" to="/profile">My Profile</NavLink></li>
                                            <li className='submenu mt-2'><NavLink style={navLinkStyles} className="submenu text-grey ps-3" to="/orders">My Orders</NavLink></li>
                                            <li className='mt-2'><NavLink style={navLinkStyles} className="submenu text-grey  ps-3" to="/wishlist">My Wishlist</NavLink></li>
                                            <li className='mt-2'><a className="submenu logout-btn  my-auto ps-3 text-decoration-none text-grey"
                                                onClick={() => logoutClick()}>Logout</a></li>
                                        </ul>
                                    </li>
                            }
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Categories
                                </a>
                                <div class="megamenu dropdown-menu ps-2 pe-2">
                                    {categories && categories.map(mainCat => {
                                        let mainCategoryUrl = "/products/?mainCat=" + mainCat.categoryName
                                        return <ul className=''>
                                            <li className='fw-bold text-pink mt-2'><NavLink style={navLinkStyles}
                                                className="text-pink"
                                                to={mainCategoryUrl}>{mainCat.categoryName}</NavLink></li>
                                            {
                                                mainCat.subCategory && mainCat.subCategory.map(item => {
                                                    let subCategoryUrl = mainCategoryUrl + "&subCat=" + item.subCategoryName
                                                    return <li className='mt-2'><NavLink style={navLinkStyles}
                                                        className="submenu text-grey font-weight-normal"
                                                        to={subCategoryUrl}>{item.subCategoryName}</NavLink></li>
                                                })
                                            }
                                            <li className='mt-2'><NavLink style={navLinkStyles}
                                                className="text-grey submenu"
                                                to={mainCategoryUrl}>View All</NavLink></li>
                                        </ul>
                                    })}
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">
                                    <NavLink style={navLinkStyles} className="text-grey" to="/products?viewAll=all">View All Products</NavLink>
                                </a>
                            </li>
                        </ul>
                        <div class="d-flex">
                            <input class="searchbox form-control me-2 rounded-0"
                                type="search"
                                placeholder="Search Products & Brands"
                                aria-label="Search"
                                value={searchText}
                                onChange={(e) => setSearchText(e.target.value)}
                            /><button className='searchbtn rounded-0 bg-white border-0 me-4' onClick={() => search()}><BsSearch /></button>
                            <span className='h2 pe-3'><AiTwotoneHeart className='text-pink icon' onClick={() => navigate('/wishlist')} /></span>
                            <span className='h2'><FiShoppingBag className='icon text-pink' onClick={() => navigate('/cart')} /></span>
                            { }
                        </div>
                    </div>
                </div>
            </nav>
        </Section >
    )
}

export const Section = styled.section`
${textStyles}
${btnStyles}
${cursorPointer}

.icon{
    &:hover{
        color:grey;
    }
}
.logout-btn,.icon{
   cursor: pointer;
}
.login-menu{
    margin-top:17px !important;
   
}
.nav-login,.home{
    cursor: pointer;
}
.megamenu ul {
    list-style: none;
    padding: 0;
    width:8rem;
}
.megamenu ul li:hover{
    color:pink;
}
.megamenu.show {
    display: flex !important
}

.submenu{
    &:hover{
        color: #ff8f9c;
        font-weight: bold;
    }
}


.megamenu li a {
    color: grey;
    padding: 0.5rem 1rem;
}



.megamenu li:first-child a {
    font-weight: bold;
    font-size: 1.2rem;
    color: black;
}

.searchbox {
    width: 40rem !important
}

.searchbtn {
    margin-left: -2.5rem;
    height: 2.4rem;
    margin-top: 0.2rem;

}
`
