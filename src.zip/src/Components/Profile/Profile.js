import React, { useEffect, useState } from 'react'
import { useAuth } from '../ContextAPI/AuthContext'
import { getItemsByFilter, updateItemById } from '../../Services/CRUDServices'
import { PROFILEJSONURL } from '../../Shared/Constants'
import styled from 'styled-components'
import { btnStyles, textStyles } from '../../Shared/ReusableStyles'
import { validateAddress } from '../../Services/Validate'
import { toast } from 'react-toastify'

export default function Profile() {

    let intialAddress = {
        name: "",
        phone: '',
        email: "",
        street: "",
        city: "",
        state: "",
        pincode: ""
    }
    const [address, setAddress] = useState(intialAddress)
    const [addressErrors, setAddressErrors] = useState({})
    const [updateId, setUpdateId] = useState(0)
    //context api details ============================================>>>
    const { authUser, setAuthUser, isLoggedIn, setIsLoggedIn, setUserInfo, isGuest, setIsGuest } = useAuth()

    useEffect(() => {
        getProfileDetails()
    }, [])

    const getProfileDetails = () => {
        getItemsByFilter(PROFILEJSONURL, "loginId", authUser.id).then(res => {
            setAddress(res.data[0].address)
            setUpdateId(res.data[0].id)

        })
    }
    const handleInputChange = (e) => {
        setAddress({ ...address, [e.target.name]: e.target.value })

    }

    const saveProfile = () => {
        let errors = validateAddress(address)
        setAddressErrors(errors)
        if (Object.keys(errors).length > 0)
            return false;
        updateItemById(PROFILEJSONURL, updateId, { address: address })
            .then(res => toast.success('Updated'))
            .catch(res => toast.warn('error occurred'))
        return false;
    }

    return (
        <Section className='container text-center'>
            <div className='w-100 my-auto'>

                <h2 className='text-pink mt-4'>PROFILE INFORMATION</h2>
                <h5 className='text-grey mt-4 mb-3'>Hey there! Fill in your details for a personalized Selvaa's Fashion shopping experience.</h5>
                <div className='row'>
                    <div className='col-3 offset-3'>
                        <label className='text-start w-100 mb-3 text-grey'>Name : </label>
                        <input type="text" name="name"
                            onChange={e => handleInputChange(e)}
                            value={address.name} placeholder='Name' className='w-100 mb-2' />
                        {addressErrors.name && <p className='small text-danger text-start'>{addressErrors.name}</p>}

                    </div>
                    <div className='col-3'>
                        <label className='text-start w-100 mb-3  text-grey'>Phone No: </label>
                        <input type="number" name="phone"
                            onChange={e => handleInputChange(e)}
                            value={address.phone} placeholder='Phone' className='w-100 mb-2' />
                        {addressErrors.phone && <p className='small text-danger text-start'>{addressErrors.phone}</p>}

                    </div>
                </div>

                <div className='row'>
                    <div className='col-3 offset-3'>
                        <label className='text-start w-100 mb-3 text-grey'>Email : </label>
                        <input type="email" name="email"
                            onChange={e => handleInputChange(e)}
                            value={address.email} placeholder='Email' className='mt-2 w-100 mb-2' />
                        {addressErrors.email && <p className='small text-danger text-start'>{addressErrors.email}</p>}

                    </div>
                    <div className='col-3'>
                        <label className='text-start w-100 mb-3  text-grey'>Flat No & Street: </label>
                        <input type="text" name="street"
                            onChange={e => handleInputChange(e)}
                            value={address.street} placeholder='FlatNo & Street' className='mt-2 w-100 mb-2' />
                        {addressErrors.street && <p className='small text-danger text-start'>{addressErrors.street}</p>}

                    </div>
                </div>

                <div className='row'>
                    <div className='col-3 offset-3'>
                        <label className='text-start w-100 mb-3 text-grey'>City : </label>
                        <input type="text" name="city"
                            onChange={e => handleInputChange(e)}
                            value={address.city} placeholder='City' className='mt-2 w-100 mb-2' />
                        {addressErrors.city && <p className='small text-danger text-start'>{addressErrors.city}</p>}

                    </div>
                    <div className='col-3'>
                        <label className='text-start w-100 mb-3  text-grey'>State </label>
                        <input type="text" name="state"
                            onChange={e => handleInputChange(e)}
                            value={address.state} placeholder='State' className='mt-2 w-100 mb-2' />
                        {addressErrors.state && <p className='small text-danger text-start'>{addressErrors.state}</p>}

                    </div>
                </div>

                <div className='row'>
                    <div className='col-3 offset-3'>
                        <label className='text-start w-100 mb-3 text-grey'>Pincode : </label>
                        <input type="number" name="pincode"
                            onChange={e => handleInputChange(e)}
                            value={address.pincode} placeholder='Pincode' className='mt-2 w-100 mb-2' />
                        {addressErrors.pincode && <p className='small text-danger text-start'>{addressErrors.pincode}</p>}

                    </div>
                    <div className='col-3 mt-5'>
                        <button className='btn btn-pink' onClick={() => saveProfile()}>Save</button>
                    </div>
                </div>


            </div>
        </Section>
    )
}
export const Section = styled.div`
${textStyles}
${btnStyles}
.priceDiv{
    background-color: #e1ecf1;
    border-left:5px solid #ff8f9c;
    display:inline;
}
.shipbtn{
    background-color: #ff8f9c;
    border-radius: 0;
}
input{
  background: transparent;
  border: none;
  border-bottom: 1px solid #ff8f9c;
  -webkit-box-shadow: none;
  box-shadow: none;
  outline: none;
  border-radius: 0;

}

`
