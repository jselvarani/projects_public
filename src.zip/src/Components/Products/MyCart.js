import React, { useEffect, useState } from 'react'
import { addNewItem, deleteItemById, getItemById, getItemsByFilter, updateItemById } from '../../Services/CRUDServices'
import { CARTJSONURL, ORDERSJSONURL, PRODUCTSJSONURL, PROFILEJSONURL } from '../../Shared/Constants'
import { useNavigate } from 'react-router-dom'
import { getValidAuthentication } from '../../Services/LoginLogics'
import { useAuth } from '../ContextAPI/AuthContext'
import styled from 'styled-components'
import { btnStyles, textStyles } from '../../Shared/ReusableStyles'
import { toast } from 'react-toastify'
import { validateAddress } from '../../Services/Validate'
import { getToday } from '../../Services/MomentService'
import { RiDeleteBin6Fill } from 'react-icons/ri'

export default function MyCart() {

    let totalNumOfItems = 0
    let bagTotalAmount = 0
    let bagDiscountAmount = 0
    let orderTotalAmount = 0
    let cartUpdateCount = 0;
    let intialAddress = {
        name: "",
        phone: '',
        email: "",
        street: "",
        city: "",
        state: "",
        pincode: ""
    }
    //state variables ==============================================>>>>
    const [myCart, setMyCart] = useState([])
    const [myCartId, setMyCartId] = useState(0)
    const [tot, setTot] = useState(0)
    const [address, setAddress] = useState(intialAddress)
    const [proceed, setProceed] = useState(1)
    const [cartUpdate, setCartUpdate] = useState(0)
    const [addressErrors, setAddressErrors] = useState({})

    //context api details ============================================>>>
    const { authUser, setAuthUser, isLoggedIn, setIsLoggedIn, setUserInfo, isGuest, setIsGuest } = useAuth()

    //navigate =====================>>>
    const navigate = useNavigate()

    useEffect(() => {
        const isLoggedIn = getValidAuthentication()
        if (!isGuest) {
            if (!isLoggedIn || !authUser) {
                navigate('/login')

            }
        }
        getMyCartItems()
    }, [cartUpdate])

    //user defined functions ================================================>>>>
    const getMyCartItems = async () => {
        setCartUpdate(0)
        let customerId
        if (isGuest) {
            customerId = 0;
        } else {
            customerId = authUser.id;
        }

        //get Cart Data from json file ======================================>>>
        await getItemsByFilter(CARTJSONURL, "customerId", customerId).then(res => {
            setMyCart(res.data[0].products);
            setMyCartId(res.data[0].id)
            console.log(myCart)
            console.log(myCartId)
        })

        //getting Address from profile =====================================>>>>
        if (authUser.id > 0) {
            await getItemsByFilter(PROFILEJSONURL, "profileId", authUser.id).then(res => {
                setAddress(res.data[0].address)
                console.log(res.data[0].address)
            })
        }
    }

    //cart Quantity update ===================================================>>>>
    const changeQuantity = async (e, pid, size, qty) => {
        let newProducts = []
        Promise.all(myCart.map(async item => {
            if (item.productId == pid && item.chosenSize == size) {
                let qty = e.target.value
                let newInnerObj = { ...item, quantity: qty }
                newProducts.push(newInnerObj)

            } else {
                newProducts.push(item)
            }
        }))

        await updateItemById(CARTJSONURL, myCartId, { products: newProducts })
            .then(res => toast('Cart updated'))
            .catch(err => toast('Some Error'))
        setCartUpdate(cartUpdate + 1)
        return;

    }

    //cart delete item ==============================================>>>>>>
    const deleteFromCart = async (pid, size) => {
        let newProducts = []
        Promise.all(myCart.map(async item => {
            if (item.productId == pid && item.chosenSize == size) {
                console.log('leave this product')

            } else {

                newProducts.push(item)
            }
        }))

        await updateItemById(CARTJSONURL, myCartId, { products: newProducts })
            .then(res => toast('Item Removed'))
            .catch(err => toast('Some Error'))
        setCartUpdate(cartUpdate + 1)
        return;
    }

    //Proceed to ship =================================================>>>>>
    const proceedToship = async () => {
        setProceed(1)
        if (myCart.length == 0) {
            toast.warn('You Dont Have Anything In Your Bag')
            return false;
        }
        let errors = validateAddress(address)
        setAddressErrors(errors)
        if (Object.keys(errors).length > 0)
            return false;

        myCart.map(async item => {
            let avlSize = []
            await getItemById(PRODUCTSJSONURL, item.productId).then(res => {
                res.data.sizesAvailable.map(sizesavl => {
                    if (sizesavl.size === item.chosenSize) {
                        avlSize.push({ size: sizesavl.size, count: sizesavl.count - item.quantity })
                    }
                    else
                        avlSize.push(sizesavl)
                })
                console.log(avlSize);
            })
            //uncomment while demo (json server crashes with this line)
            await updateItemById(PRODUCTSJSONURL, item.productId, { sizesAvailable: avlSize }).then(res => console.log(res))

        })

        let customerId
        let memberType = 'member'
        if (isGuest) {
            customerId = 0;
            memberType = 'Guest'
        }
        else
            customerId = authUser.id
        let orderObj = {
            customerId: customerId,
            customerType: memberType,
            date: getToday(),
            shippingAddress: address,
            orderItems: myCart,
            orderTotal: orderTotalAmount

        }
        console.log(orderObj)
        await deleteItemById(CARTJSONURL, myCartId).then(res => console.log(res))
        await addNewItem(ORDERSJSONURL, orderObj).then(res => {
            toast.success('Thanks For Ordering With Selvaas Fashion')
            navigate('/orders')

        }).catch(err => toast.warn('Error Occurred'))

    }
    //input Change handler
    const handleInputChange = (e) => {
        setAddress({ ...address, [e.target.name]: e.target.value })

    }

    return (
        <Section className='container'>
            <div className='row mt-3'>
                <div className='col-9 border border-1'>
                    <h2 className='text-grey mt-2 text-start'>My Bags</h2>
                    <div className='cartContainer pt-3'>
                        {myCart.length == 0 && "Your Bag Is Empty"}
                        {myCart && myCart.map(item => {
                            let mrp = item.MRP * item.quantity
                            let price = item.price * item.quantity
                            let saving = mrp - price
                            bagTotalAmount += mrp
                            bagDiscountAmount += saving
                            orderTotalAmount += price
                            return <div class="card mb-3" key={item.productId}>
                                <div class="row g-0">
                                    <div class="col-md-2">
                                        <img src={process.env.PUBLIC_URL + "/" + item.imageUrl} className='img-fluid' />
                                    </div>
                                    <div class="col-md-10">
                                        <div class="card-body">
                                            <div className='row'>
                                                <div className='col-3 text-pink fw-bold'>{item.productName}</div>
                                                <div className='col-3'>Size: <span className='text-grey fw-bold me-2'>{item.chosenSize}</span> Qty: <select value={item.quantity} onChange={(e) => changeQuantity(e, item.productId, item.chosenSize, item.quantity)}><option>1</option><option>2</option><option>3</option><option>4</option></select> </div>
                                                <div className='col-6 text-end'>
                                                    <p className='text-pink'>Savings: &#8377;  <b>{saving}</b></p>
                                                    <p className='text-pink'><s><b> &#8377; {mrp}</b></s> ({item.offer})</p>
                                                    <div className='priceDiv ps-2 pe-2 fw-bold'>&#8377;  {price}</div>
                                                    <div><button className='btn btn-pink mt-3' onClick={() => deleteFromCart(item.productId, item.chosenSize)}><RiDeleteBin6Fill /></button></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        })
                        }

                    </div>
                </div>
                <div className='col-3 border border-1'>
                    <div className='border border-1 ps-2 pe-2'>
                        <div>
                            <p className='fw-bold mt-4 text-start'>Order Details </p>

                            <div className='row'>
                                <div className='col-7 text-start'>Bag Total</div>
                                <div className='col-5 text-end'><p>&#8377; {bagTotalAmount}</p></div>
                            </div>
                            <div className='row'>
                                <div className='col-7  text-start'>Bag Discount</div>
                                <div className='col-5 text-end'><p>- &#8377; {bagDiscountAmount}</p></div>
                            </div>
                            <div className='row'>
                                <div className='col-7 text-grey  text-start'>Delivery Fee</div>
                                <div className='col-5 text-end'><p>Free <s>&#8377; 99</s></p></div>
                            </div>
                            <div className='row'>
                                <div className='col-7 fw-bold  text-start'>Order Total</div>
                                <div className='col-5 text-end fw-bold'><p>&#8377; {orderTotalAmount}</p></div>
                            </div>
                        </div>
                    </div>
                    {
                        proceed === 1 && <div className='w-100 border border-1 mt-2 mb-2 ps-3 pb-3 pe-3'>
                            <p className='text-start fw-bold mt-3'>Shipping Address</p>
                            <input type="text" name="name"
                                onChange={e => handleInputChange(e)}
                                value={address.name} placeholder='Name' className='w-100 mb-2' />
                            {addressErrors.name && <p className='small text-danger text-start'>{addressErrors.name}</p>}

                            <input type="number" name="phone"
                                onChange={e => handleInputChange(e)}
                                value={address.phone} placeholder='Phone' className='mt-2 w-100 mb-2' />
                            {addressErrors.phone && <p className='small text-danger text-start'>{addressErrors.phone}</p>}

                            <input type="email" name="email"
                                onChange={e => handleInputChange(e)}
                                value={address.email} placeholder='Email' className='mt-2 w-100 mb-2' />
                            {addressErrors.email && <p className='small text-danger text-start'>{addressErrors.email}</p>}
                            <input type="text" name="street"
                                onChange={e => handleInputChange(e)}
                                value={address.street} placeholder='FlatNo & Street' className='mt-2 w-100 mb-2' />
                            {addressErrors.street && <p className='small text-danger text-start'>{addressErrors.street}</p>}
                            <input type="text" name="city"
                                onChange={e => handleInputChange(e)}
                                value={address.city} placeholder='City' className='mt-2  w-100 mb-2' />
                            {addressErrors.city && <p className='small text-danger text-start'>{addressErrors.city}</p>}
                            <input type="text" name="state"
                                onChange={e => handleInputChange(e)}
                                value={address.state} placeholder='State' className='mt-2  w-100 mb-2' />
                            {addressErrors.state && <p className='small text-danger text-start'>{addressErrors.state}</p>}
                            <input type="number" name="pincode"
                                onChange={e => handleInputChange(e)}
                                value={address.pincode} placeholder='Pincode' className='mt-2  w-100 mb-2' />
                            {addressErrors.pincode && <p className='small text-danger text-start'>{addressErrors.pincode}</p>}
                        </div>
                    }
                    <div className='w-100'><button className='btn btn-pink ship-btn rounded-0 w-100' onClick={() => proceedToship()}>Proceed To Shipping</button></div>
                </div>
            </div>
        </Section>
    )
}
export const Section = styled.div`
${textStyles}
${btnStyles}
.priceDiv{
    background-color: #e1ecf1;
    border-left:5px solid #ff8f9c;
    display:inline;
}
.shipbtn{
    background-color: #ff8f9c;
    border-radius: 0;
}
input{
  background: transparent;
  border: none;
  border-bottom: 1px solid #ff8f9c;
  -webkit-box-shadow: none;
  box-shadow: none;
  outline: none;
  border-radius: 0;

}

`
