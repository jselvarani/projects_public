import React, { useEffect, useState } from 'react'
import styled from 'styled-components'
import { imageZoomEffect, textStyles } from '../../Shared/ReusableStyles'
import { PRODUCTSJSONURL } from '../../Shared/Constants'
import { getAllItems, getItemsByFilter, getItemsByTwoFilter } from '../../Services/CRUDServices'
import { useNavigate, useSearchParams } from 'react-router-dom'
import ReactStars from 'react-stars'

export default function Products() {
    const [products, setProducts] = useState([])
    const navigate = useNavigate()
    const [searchParams, setSearchParams] = useSearchParams()
    const mainCat = searchParams.get('mainCat')
    const all = searchParams.get('viewAll')
    const subCat = searchParams.get('subCat')
    const search = searchParams.get('search')
    const sortby = searchParams.get('sortBy')
    const [priceFilter, setPriceFilter] = useState(0)
    const [colorFilter, setColorFilter] = useState('')
    const [ratingFilter, setRatingFilter] = useState(0)

    useEffect(() => {
        getProducts()
    }, [mainCat, subCat, search, all, sortby])

    //user defined function ==================================>>>>
    const getProducts = () => {
        if (mainCat == null)
            getAllItems(PRODUCTSJSONURL).then(res => {
                if (search && search.length > 0) {
                    let pdt = res.data.filter(item => item.productName.toLowerCase().includes(search.toLowerCase()))
                    setProducts(pdt)
                    console.log(pdt)
                } else {
                    if (sortby == 'priceAscending') {
                        let pdt = res.data.sort((a, b) => parseInt(a.price) - parseInt(b.price));
                        console.log(pdt)
                        setProducts(pdt)

                    } else if (sortby == 'priceDescending') {
                        let pdt = res.data.sort((a, b) => parseInt(b.price) - parseInt(a.price));
                        console.log(pdt)
                        setProducts(pdt)
                    }
                    else
                        setProducts(res.data)
                }
            })
        else if (subCat == null)
            getItemsByFilter(PRODUCTSJSONURL, "category", mainCat).then(res => setProducts(res.data))
        else
            getItemsByTwoFilter(PRODUCTSJSONURL, "category", mainCat, "subCategory", subCat).then(res => setProducts(res.data))
    }
    return (
        <Section className='container'>
            <div className='row mt-3'>
                <div className='col-2 border border-1 text-start'>
                    <h4>Refine By</h4>
                    <span className='h5 text-pink'>Price</span>
                    <span className='ms-5'><a className="filterClear" onClick={() => setPriceFilter(0)}>Clear</a></span>
                    <div className='ms-3 mt-3 mb-3'>
                        <input type="radio" name="price" value="400" className='mt-1'
                            onClick={(e) => setPriceFilter(e.target.value)}
                        /> <label>Less than 400</label><br></br>
                        <input type="radio" name="price" className='mt-3'
                            onClick={(e) => setPriceFilter(e.target.value)}
                            value="700" /> <label>Less than 700</label><br></br>
                        <input type="radio" name="price" className='mt-3'
                            onClick={(e) => setPriceFilter(e.target.value)}
                            value="1000" /> <label>Less than 1000</label>
                    </div>

                    <span className='h5 text-pink mt-4'>Rating</span>
                    <span className='ms-5'><a className="filterClear" onClick={() => setRatingFilter(0)}>Clear</a></span>
                    <div className='ms-3 mb-3'>
                        <div className="stars" onClick={(e) => setRatingFilter(4)}
                            value="4"> <label> <ReactStars className="stars" size={24} count={5} value={4} edit={false} color2={'#ff9529'} /> </label></div>
                        <div className="stars" onClick={(e) => setRatingFilter(3)}
                            value="3"> <label><ReactStars className="stars" size={24} count={5} value={3} edit={false} color2={'#ff9529'} /></label></div>
                    </div>

                    <span className='h5 text-pink'>Color</span>
                    <span className='ms-5'><a className="filterClear"
                        onClick={() => setColorFilter('')}>Clear</a></span>
                    <div className='ms-3 mt-3 mb-4'>
                        <input type="radio" name="color" value="black" className='mt-1'
                            onClick={(e) => setColorFilter(e.target.value)}
                        /> <label>Black</label><br></br>
                        <input type="radio" name="color" className='mt-3'
                            onClick={(e) => setColorFilter(e.target.value)}
                            value="blue" /> <label>Blue</label><br></br>
                        <input type="radio" name="color" className='mt-3'
                            onClick={(e) => setColorFilter(e.target.value)}
                            value="white" /> <label>White</label><br></br>
                        <input type="radio" name="color" className='mt-3'
                            onClick={(e) => setColorFilter(e.target.value)}
                            value="peach" /> <label>Peach</label><br></br>
                        <input type="radio" name="color" className='mt-3'
                            onClick={(e) => setColorFilter(e.target.value)}
                            value="beige" /> <label>Beige</label><br></br>
                        <input type="radio" name="color" className='mt-3'
                            onClick={(e) => setColorFilter(e.target.value)}
                            value="green" /> <label>Green</label><br></br>
                        <input type="radio" name="color" className='mt-3'
                            onClick={(e) => setColorFilter(e.target.value)}
                            value="yellow" /> <label>Yellow</label>
                    </div>
                    <span className="text-grey h6 mt-5 text-center clearall"
                        onClick={() => { setPriceFilter(0); setColorFilter(''); setRatingFilter(0) }}>
                        Clear All</span>
                </div>

                <div className='col-10'>
                    <div className='row'>
                        <div className='col-9'><h2 className='h3 text-pink text-start'>New Products</h2></div>
                        {mainCat == null && <div className='col-3'>
                            Sort By
                            <select onChange={(e) => navigate('/products/?sortBy=' + e.target.value)} className='ms-2'>
                                <option>None</option>
                                <option value="priceAscending">Price (Lower first)</option>
                                <option value="priceDescending">Price (Higher first)</option>
                            </select>
                        </div>}
                    </div>

                    <div className='d-flex row'>
                        <hr />
                        {products.length == 0 && 'No Results Found'}
                        {
                            products.map(item => {
                                if (priceFilter > 0 && parseInt(item.price) > parseInt(priceFilter))
                                    return ''
                                else if (colorFilter && item.color != colorFilter)
                                    return ''
                                else if (ratingFilter && parseFloat(item.averageRating) < parseFloat(ratingFilter))
                                    return ''
                                else
                                    return <div class="col-3 ps-3 mt-3">
                                        <div onClick={() => (navigate)('../product/' + item.id)} className='card p-2'>
                                            <div className='img-card '>
                                                <img src={process.env.PUBLIC_URL + "/" + item.imageUrl} className='card-img-top' />
                                            </div>
                                            <div class="card-body border border-0 p-0 pt-2">
                                                <div class="card-text text-start text-pink text-uppercase fw-bold h5">{item.subCategory}</div>
                                                <p class="card-text text-start text-grey h6">{item.productName}</p>
                                                <p className='text-start'>
                                                    <span className='text-grey'><s>&#8377; {item.MRP}</s></span>
                                                    <span className='muted ms-2'><small>({item.offer})</small></span>
                                                    <p className='h4'>
                                                        <ReactStars size={24} count={5} value={item.averageRating} edit={false} color2={'#ff9529'} />
                                                    </p>
                                                </p>
                                                <p>Offer Price <span className='fw-bold'>&#8377;  {item.price}</span></p>
                                            </div>
                                        </div>
                                    </div>
                            })
                        }
                    </div>
                </div>
            </div>
        </Section >
    )
}
export const Section = styled.div`
${imageZoomEffect}
${textStyles}

.clearall{
    cursor: pointer;
}
.reactstar{
    cursor: pointer;
}
.stars{
    cursor: pointer;
}
.img-card{
    overflow: hidden;
}
.filterClear{
    text-decoration: none;
    color:grey
}
.card,.filterClear {
    cursor: pointer;
}
`
