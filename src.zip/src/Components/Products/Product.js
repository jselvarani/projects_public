import React, { useEffect, useState } from 'react'
import { NavLink, useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { addNewItem, getItemById, getItemsByFilter, getItemsByTwoFilter, updateItemById } from '../../Services/CRUDServices'
import { ADDTOCART, ADDTOWISHLIST, CARTJSONURL, GOTOCART, PRODUCTSJSONURL, REMOVEFROMWISHLIST, WISHLISTJSONURL } from '../../Shared/Constants'
import styled from 'styled-components'
import { btnStyles, imageZoomEffect, textStyles } from '../../Shared/ReusableStyles'
import { AiFillStepBackward, AiTwotoneHeart } from 'react-icons/ai'
import { FiShoppingBag } from 'react-icons/fi'
import { toast } from 'react-toastify'
import { getValidAuthentication } from '../../Services/LoginLogics'
import axios from 'axios'
import { useAuth } from '../ContextAPI/AuthContext'
import { constructNewObj } from '../../Services/OtherServices'
import { BsArrowBarLeft, BsBack } from 'react-icons/bs'
import ReactStars from 'react-stars'

export default function Product() {

    const { authUser, setAuthUser, isLoggedIn, setIsLoggedIn, setUserInfo, isGuest, setIsGuest } = useAuth()

    const [product, setProduct] = useState({})
    const navigate = useNavigate()
    const [addToCartText, setAddToCartText] = useState(ADDTOCART)
    const [wishlistText, setWishlistText] = useState(ADDTOWISHLIST)
    const [updateProduct, setUpdateProduct] = useState({})
    const [size, setSize] = useState('')
    const { id } = useParams()
    const [ratingSubmit, setRatingSubmit] = useState(0)

    useEffect(() => {
        getItmById()
    }, [ratingSubmit])

    const getItmById = () => {
        getItemById(PRODUCTSJSONURL, id).then(res => setProduct(res.data))
    }

    const addToCart = async () => {
        const isLoggedIn = getValidAuthentication()
        if (!isLoggedIn || !authUser) {
            if (!isGuest)
                if (window.confirm('Press Ok to Login. Press Cancel to Continue as guest')) {
                    navigate('/login?return=' + id)
                    return;
                } else {
                    if (window.confirm('You are supposed to Continue as Guest. Your Data will lost after this session ends. Is it Ok?')) {
                        setIsGuest(true)

                    } else {
                        navigate('/login?return=' + id)
                        return;
                    }

                }
        }

        if (!size) {
            toast.warn('Choose Size')
            return false;
        }
        let existing = {};
        let customerId = 0
        if (authUser)
            customerId = authUser.id
        else if (isGuest)
            customerId = 0

        //new Cart Entry============================================================>>>
        await getItemsByFilter(CARTJSONURL, "customerId", customerId).then(res => existing = res.data)

        if (existing.length === 0) {
            //constructing new obj
            let newObj = {
                customerId: customerId,
                "products": [
                    {
                        productId: product.id,
                        productName: product.productName,
                        imageUrl: product.imageUrl,
                        MRP: product.MRP,
                        price: product.price,
                        offer: product.offer,
                        quantity: 1,
                        chosenSize: size
                    }
                ]
            }
            //inserting fresh cart entry
            await addNewItem(CARTJSONURL, newObj)
                .then(res => { toast.success('Added to Cart'); setAddToCartText(GOTOCART) })
                .catch(err => toast.warn('Some Error'))
        }
        else {
            let newProducts = []
            let isAdded = 0;
            existing[0].products.map(item => {

                if (item.productId == id && item.chosenSize == size) {
                    let qty = item.quantity + 1
                    let newInnerObj = { ...item, quantity: qty }
                    newProducts.push(newInnerObj)
                    isAdded = 1

                } else {

                    newProducts.push(item)
                }
            })
            if (isAdded == 0) {
                let pdt = {
                    productId: product.id,
                    productName: product.productName,
                    imageUrl: product.imageUrl,
                    MRP: product.MRP,
                    price: product.price,
                    offer: product.offer,
                    quantity: 1,
                    chosenSize: size
                }
                newProducts.push(pdt)
            }
            await updateItemById(CARTJSONURL, existing[0].id, { products: newProducts })
                .then(res => toast('Cart updated'))
                .catch(err => toast('Some Error'))

        }
        return;

    }

    const addToWishlist = async () => {
        const isLoggedIn = getValidAuthentication()
        if (!isLoggedIn || !authUser) {
            toast.warn('You Must Login To Continue..')
            return false;

        }
        let newObj = constructNewObj(product, authUser.id)
        await addNewItem(WISHLISTJSONURL, newObj)
            .then(res => { toast.success('Added to WishList'); setWishlistText(REMOVEFROMWISHLIST) })
            .catch(err => toast.warn('Some Error'))

    }

    const rateMe = (newRating) => {

        if (ratingSubmit == 1) {
            toast.warn('Already Rated')
            return false;
        }

        let rating = ((product.averageRating * product.ratingCounts) + newRating) / (product.ratingCounts + 1)
        let finalRating = rating.toFixed(1)
        let ratingCount = parseInt(product.ratingCounts) + 1
        updateItemById(PRODUCTSJSONURL, id, { averageRating: finalRating, ratingCounts: ratingCount }).then(res => toast('Rating Submitted')).catch(err => toast('error'))
        // setRatingSubmit(1)
        return finalRating;

    }
    return (
        <Section className='container-fluid'>
            <nav aria-label="breadcrumb" className='bread-crumb'>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <NavLink to='/products' className="text-pink">Products</NavLink>
                    </li>
                    <li class="breadcrumb-item">
                        <NavLink to={'/products/?maincat=' + product.category} className="text-pink">
                            {product.category}
                        </NavLink>
                    </li>
                    <li class="breadcrumb-item">
                        <NavLink className="text-pink"
                            to={'/products/?maincat=' + product.category + '&subCat=' + product.subCategory}>
                            {product.subCategory}
                        </NavLink>
                    </li>
                </ol>
            </nav>
            <div className='row mt-3'>
                <div className='col-1 offset-1'><h1 className='text-pink back-btn'><AiFillStepBackward onClick={() => navigate(-1)} /></h1></div>
                <div className='col-4 border border-0 img-div ps-0 pe-0'>
                    <div className='w-100'>
                        <img src={process.env.PUBLIC_URL + "/" + product.imageUrl} className='img-fluid w-100' />
                    </div>
                </div>
                <div className='col-4 border border-1 ms-3'>
                    <h3 className='text-pink'>{product.productName}</h3>
                    <h1>&#8377;{product.price}</h1>
                    <h5 className='text-grey muted small'>MRP <s>&#8377;{product.MRP}</s> (<span className='fw-bold'>{product.offer}</span>)</h5>
                    {product.color}<br />
                    Available Sizes<br /><div className='mt-3'>
                        {
                            product.sizesAvailable && product.sizesAvailable.map(item => {
                                return <span className='sizesSpan my-auto'>{item.size}</span>
                            })
                        }</div>
                    <div className='mt-4'>
                        <button className='btn btn-pink w-50' onClick={() => addToCart()}>
                            <FiShoppingBag className='btn-inside-icon me-2' />{addToCartText}</button>
                        <select className='ms-5 rounded rounded-2 btn-outline-pink' value={size} onChange={(e) => setSize(e.target.value)}>
                            <option>-Size-</option>
                            {
                                product.sizesAvailable && product.sizesAvailable.map(item => {
                                    return <option value={item.size}>{item.size}</option>
                                })
                            }
                        </select>
                    </div>
                    <div className='mt-3'>
                        <button className='btn btn-outline-pink w-75 fw-bold' onClick={() => addToWishlist()} >
                            <AiTwotoneHeart className='btn-inside-icon me-2' />{wishlistText}</button>
                    </div>
                    <p className='text-start text-pink h5 ms-5 mt-4 ps-3'>Product Description : </p>
                    <div className='w-75 text-start ms-5' dangerouslySetInnerHTML={{ __html: product.description }}>
                    </div>
                    <div className='text-start'>
                        <div className='stars mx-auto' ><ReactStars count={5} value={product.averageRating} size={34} onChange={rateMe} color2={'#ff9529'} />
                            Rate This Product </div>
                    </div>
                </div>
            </div>
        </Section >
    )
}

export const Section = styled.div`
${textStyles}
${imageZoomEffect}

.stars{
    margin-left:25%;
   
}
.bread-crumb{
    margin-left:16%;
    margin-top:1rem;
}
.back-btn{
    cursor: pointer;
}
.sizesSpan{
   
    height: 35px;
  width: 35px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  text-align: center;
  padding-top: 0.2rem;
  margin-right:1rem;
  &:hover{
    background-color: white;
    font-weight: bold;
    cursor: pointer;
    transition: 0.5s ease-in-out;
  }

}
select{
    height:2.2rem;
}
.active{
    color:pink;
}
${btnStyles}
.img-div{
    overflow: hidden;
}
`
