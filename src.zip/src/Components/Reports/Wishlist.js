import React, { useEffect, useState } from 'react'
import styled from 'styled-components'
import { imageZoomEffect, textStyles } from '../../Shared/ReusableStyles'
import { PRODUCTSJSONURL, WISHLISTJSONURL } from '../../Shared/Constants'
import { deleteItemById, getAllItems, getItemsByFilter, getItemsByTwoFilter } from '../../Services/CRUDServices'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { RiDeleteBin4Fill } from 'react-icons/ri'
import { toast } from 'react-toastify'

export default function Wishlist() {
    const [products, setProducts] = useState([])
    const navigate = useNavigate()
    const [delId, setDelId] = useState(0)

    useEffect(() => {
        getProducts()
    }, [delId])

    const getProducts = () => {
        getAllItems(WISHLISTJSONURL).then(res => setProducts(res.data))
    }

    const deleteFromWishList = (id) => {
        deleteItemById(WISHLISTJSONURL, id)
            .then(res => toast.success('Removed From Wishlist'))
            .catch(err => toast.warn('error occurred. check log file'))
        setDelId(id)
    }

    return (
        <Section className='container'>
            <div className='row mt-3'>
                <div className='col-10 offset-1'>
                    <h2 className='text-pink  text-start'>My WishList</h2>
                    <div className='d-flex row'>
                        <hr />
                        {products && products.length == 0 && 'Wishlist is Empty'}
                        {
                            products.map(item => {
                                return <div class="col-3 ps-3 mt-3" key={item.id}>
                                    <div className='card p-2'>
                                        <div className='img-card '
                                            onClick={() => (navigate)('../product/' + item.productId)}>
                                            <img src={process.env.PUBLIC_URL + "/" + item.imageUrl} className='card-img-top' />
                                        </div>
                                        <div class="card-body border border-0 p-0 pt-2">
                                            <div class="card-text text-start text-pink text-uppercase fw-bold h5">{item.subCategory}</div>
                                            <p class="card-text text-start text-grey h6">{item.productName}</p>
                                            <p className='text-start'>
                                                <span className='fw-bold'>&#8377;  {item.price}</span>
                                                <span className='text-grey ms-4'><s>&#8377; {item.MRP}</s></span><span className='ms-3'><RiDeleteBin4Fill className='icon' onClick={() => deleteFromWishList(item.id)} /></span></p>
                                        </div>
                                    </div>
                                </div>
                            })
                        }
                    </div>
                </div>
            </div>
        </Section >
    )
}
export const Section = styled.div`
${imageZoomEffect}
${textStyles}

.img-card{
    overflow: hidden;
}

img, .icon {
    cursor: pointer;
}
`