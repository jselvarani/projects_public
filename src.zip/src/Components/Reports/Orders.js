import React, { useEffect, useState } from 'react'
import { useAuth } from '../ContextAPI/AuthContext'
import { getItemsByFilter } from '../../Services/CRUDServices'
import { ORDERSJSONURL } from '../../Shared/Constants'
import styled from 'styled-components'
import { textStyles } from '../../Shared/ReusableStyles'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

export default function Orders() {

    const { authUser, setAuthUser, isLoggedIn, setIsLoggedIn, setUserInfo, isGuest, setIsGuest } = useAuth()
    const [myOrders, setMyOrders] = useState([])
    const navigate = useNavigate()

    useEffect(() => {
        getMyOrders()
        if (authUser == undefined && isGuest == false)
            navigate('/login')

    }, [])

    const getMyOrders = () => {
        if (isGuest) {
            toast('Check Your Email for order details.')
            setIsGuest(false)
            navigate('products')
        }
        if (authUser) {
            getItemsByFilter(ORDERSJSONURL, "customerId", authUser.id).then(res => setMyOrders(res.data))
            console.log(myOrders)
        }
        else
            navigate('/login')
    }
    return (
        <Section className='container'>
            {
                myOrders && myOrders.map(item => {
                    let address = item.shippingAddress.email + "," + item.shippingAddress.street + "," + item.shippingAddress.city + "," + item.shippingAddress.pincode;
                    return <div class="card w-75 mt-5 mx-auto">
                        <div class="card-header">
                            <table>
                                <tr><td className='fw-bold'>Order Placed</td><td className='ps-5 fw-bold'>Order Total</td><td className='ps-5 fw-bold'>Ship To</td></tr>
                                <tr><td>{item.date}</td><td className='ps-5'>&#8377; {item.orderTotal}</td><td className='ps-5' ><a href="#" data-toggle="tooltip" title={address}>{item.shippingAddress.name}</a></td></tr>
                            </table>
                        </div>
                        <ul class="list-group list-group-flush">
                            {
                                item.orderItems.map(pdt => {
                                    return <li class="list-group-item">

                                        <div class="card mb-3 mt-3">
                                            <div class="row g-0">
                                                <div class="col-md-2">
                                                    <img src={process.env.PUBLIC_URL + "/" + pdt.imageUrl} className='img-fluid' />
                                                </div>
                                                <div class="col-md-8">
                                                    <div class="card-body">
                                                        <h4 class="card-title text-pink">{pdt.productName}</h4>
                                                        <p class="card-text">Size : {pdt.chosenSize} Qty: {pdt.quantity} </p>
                                                        <p class="card-text"><small class="text-muted">Price Each: &#8377; {pdt.price}</small></p>
                                                        <p class="card-text">Total &#8377; {pdt.quantity * pdt.price} </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                })
                            }
                        </ul>
                    </div>
                })
            }
        </Section>
    )
}
export const Section = styled.div`
${textStyles}
`
