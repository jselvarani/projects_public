import React, { useState } from 'react'
import styled from 'styled-components'
import { bgStyles, btnStyles, textStyles } from '../../Shared/ReusableStyles'
import rightImage from "../../Assets/images/login.jpg"
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../ContextAPI/AuthContext'
import { validate } from '../../Services/Validate'
import { checkValidUser, setAuthentication } from '../../Services/LoginLogics'

export default function Login() {
    const navigate = useNavigate()
    const { authUser, setAuthUser, isLoggedIn, setIsLoggedIn, setUserInfo } = useAuth()
    const [searchParams, setSearchParams] = useSearchParams()
    const returnId = searchParams.get('return')
    const [userName, setUserName] = useState('')
    const [password, setPassword] = useState('')
    const [loginErr, setLoginErr] = useState('')
    const [error, setError] = useState({})

    const loginClick = async () => {
        let errors = validate(userName, password)
        setError(errors)
        if (Object.keys(errors).length > 0)
            return false;
        let userAuth
        await checkValidUser(userName, password)
            .then(res => { userAuth = res; })

        if (userAuth) {
            setAuthUser(userAuth)
            setAuthentication()
            if (returnId == null)
                navigate('/')
            else
                navigate('/product/' + returnId)


        } else {
            setLoginErr('Invalid Credentials')
        }
    }
    return (
        <Section className='row container'>
            <div className='login-left-outer-div col-6 bg-pink  pe-0'>
                <div className='login-left-inner-div bg-light mx-auto'>
                    <div className="mb-3 mt-5 pt-5">
                        <h3 className='text-pink'>Buyer Login</h3>
                        <h5 className='text-danger fw-bold'>{loginErr}</h5>
                        <input type="text"
                            className="form-control w-50 mx-auto" id="text"
                            value={userName}
                            onChange={(e) => setUserName(e.target.value)}
                            placeholder="Name" />
                        {error.name && <p className='small text-danger'>{error.name}</p>}
                    </div>
                    <div className="mb-3">
                        <input type="password"
                            className="form-control  mx-auto w-50" id="password"
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            placeholder="Password" />
                        {error.password && <p className='small text-danger'>{error.password}</p>}
                    </div>
                    <div className="mb-3 mt-4 text-center">
                        <button
                            className='btn btn-pink w-50'
                            onClick={loginClick}
                        >Login</button>
                    </div>
                </div>
            </div>
            <div className='login-right-outer-div col-6 ps-0'>
                <div className='login-right-inner-div bg-light mx-auto'>
                    <div></div>
                </div>
            </div>
        </Section>
    )
}

export const Section = styled.div`
${textStyles}
${bgStyles}
${btnStyles}
.login-left-outer-div{
    height:100vh;
    .login-left-inner-div{
        height:70%;
        margin-top:3rem;
        width:90%;
        float:right;
        background-color: white;
   
    }
}

.login-right-outer-div{
    height:100vh;
    .login-right-inner-div{
        top:5rem;
        margin-top:3rem !important;
        float:left;
        width:100%;
        height:70%;
        background-image: url(${rightImage});
        background-size: cover;
        background-repeat: no-repeat;
        div{
            height:100%;
            width:100%;
            background-color: #ff8f9c;
            opacity: 0.6;
        }
    }
}

`
