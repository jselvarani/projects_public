import React from 'react'
import styled from 'styled-components'
import bottomBannerCenterImage from '../../Assets/images/bottom-banner-center.jpg'
import { textStyles } from '../../Shared/ReusableStyles'
import testimonialImage from '../../Assets/images/testi.jpg'
import { ImQuotesLeft, ImTicket } from 'react-icons/im'
import { RiShip2Line } from 'react-icons/ri'
import { TbRocket } from 'react-icons/tb'
import { BsTelePhone, BsTelephonePlus } from 'react-icons/bs'
import { IoTicketOutline } from 'react-icons/io'
import { GiLobArrow, GiReturnArrow } from 'react-icons/gi'

export default function BottomBanner() {
    return (
        <Section className='container'>
            <div className='row'>
                <div className='col-3'>
                    <div className='border ps-3 border-1 pe-3 pb-3'>
                        <h4 className='text-start pt-2'>Testimonial</h4>
                        <hr />
                        <div className='border border-1 rounded rounded-3'>
                            <img src={testimonialImage} className='rounded w-50 p-3 rounded-circle' />
                            <h6 className='text-grey'>ALAN DOE</h6>
                            <h5>CEO & Founded Invision</h5>
                            <h2 className='text-pink'><ImQuotesLeft /></h2>
                            <p className='h5 lh-lg text-grey ps-5 pe-5 pb-3'>Had a Best Shopping Experience Here. at reasonable cost with best quality. Just Go for it </p>
                        </div>
                    </div>
                </div>

                <div className='btm-banner col-6  rounded rounded-3'>
                    <div className='mx-auto text-center w-50'>
                        <h3 className='bg-dark text-white fw-bold rounded rounded-1 p-2'>25% DISCOUNT</h3>
                        <h3 className='fw-bold'>Summer</h3>
                        <h3 className='fw-bold'>Collection</h3>
                        <h4 className='text-grey'>Starting @ 100</h4>
                        <h4 className='fw-bold text-dark'>SHOP NOW</h4>
                    </div>
                </div>

                <div className='col-3'>
                    <div className='border border-1 ps-3 pe-3 pb-3'>
                        <h4 className='text-start pt-2'>Our Services</h4>
                        <hr />
                        <div className='border border-1 rounded rounded-3'>
                            <div class="card mb-0 ps-3 pe-3 border border-0">
                                <div class="row g-0">
                                    <div class="col-md-1 mx-auto my-auto">
                                        <RiShip2Line className='h1 text-pink' />
                                    </div>
                                    <div class="col-md-11">
                                        <div class="card-body ms-3">
                                            <h5 class="card-title fw-bold text-start">World Wide Delivery</h5>
                                            <p class="card-text fw-bold text-grey text-start">For order above 1000 </p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mb-0 ps-3 pe-3 border border-0">
                                <div class="row g-0">
                                    <div class="col-md-1 mx-auto my-auto">
                                        <TbRocket className='h1 text-pink' />
                                    </div>
                                    <div class="col-md-11">
                                        <div class="card-body ms-3">
                                            <h5 class="card-title fw-bold text-start">Next Day Delivery</h5>
                                            <p class="card-text fw-bold text-grey text-start">India Orders Only</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mb-0 ps-3 pe-3 border border-0">
                                <div class="row g-0">
                                    <div class="col-md-1 mx-auto my-auto">
                                        <BsTelephonePlus className='h2 fw-bold text-pink' />
                                    </div>
                                    <div class="col-md-11">
                                        <div class="card-body ms-3">
                                            <h5 class="card-title fw-bold text-start">Best Online Support</h5>
                                            <p class="card-text fw-bold text-grey text-start">Hours 8Am to 11Pm</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mb-0 ps-3 pe-3 border border-0">
                                <div class="row g-0">
                                    <div class="col-md-1 mx-auto my-auto">
                                        <GiLobArrow className='h2 fw-bold text-pink' />
                                    </div>
                                    <div class="col-md-11">
                                        <div class="card-body ms-3">
                                            <h5 class="card-title fw-bold text-start">Return Policy</h5>
                                            <p class="card-text fw-bold text-grey text-start">Easy & Free Return</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mb-0 ps-3 pe-3 border border-0">
                                <div class="row g-0">
                                    <div class="col-md-1 mx-auto my-auto">
                                        <ImTicket className='h2 fw-bold text-pink' />
                                    </div>
                                    <div class="col-md-11">
                                        <div class="card-body ms-3">
                                            <h5 class="card-title fw-bold text-start">30% Money Back</h5>
                                            <p class="card-text fw-bold text-grey text-start">For Orders Above 5000</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Section>
    )
}

export const Section = styled.div`
${textStyles}
.row{
    .btm-banner{
    background-image: url(${bottomBannerCenterImage});
    background-repeat: no-repeat;
    background-size: cover;

    div{
        width:60%;
        margin:4rem;
        padding:2rem;
        border-radius: 1rem;
        background-color: white;
        opacity: 0.8;
    }
}
}
`
