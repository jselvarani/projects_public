import React from 'react'
import homeBanner from '../../Assets/images/homeBanner.jpg'
import styled from 'styled-components'
import { btnStyles, textStyles } from '../../Shared/ReusableStyles'
import { useNavigate } from 'react-router-dom'

export default function Banner() {

    const navigate = useNavigate()
    return (
        <Section class="rounded container rounded pt-5 pb-5 banner-container ms-5 me-5  card h-50 text-white">
            <div class="rounded rounded-5 pt-5 pb-5" >
                <div className='rounded w-50 ms-5 ps-5 text-start'>
                    <h2 className='text-pink'>Trending Item</h2>
                    <h1 className='text-dark fw-bold'>WOMEN'S</h1>
                    <h1 className='text-dark fw-bold'>LATEST</h1>
                    <h1 className='text-dark fw-bold'>FASHION SALE</h1>
                    <h3 className='text-grey'>starting at &#8377; 100 only @ <span className='text-pink'>Selvaas Fashion</span></h3>
                    <button onClick={() => navigate('/products')} className='btn btn-pink'>SHOP NOW</button>
                </div>
            </div>
        </Section>
    )
}

export const Section = styled.div`
margin:2rem 3rem 2rem 3rem;
${textStyles}
${btnStyles}

    background-image:url(${homeBanner});
    background-repeat:no-repeat;
    background-size:cover;
    border-radius: 1rem;
   
            `
