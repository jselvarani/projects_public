import React from 'react'
import Banner from './Banner'
import BottomBanner from './BottomBanner'

export default function Home() {
    return (
        <div>
            <Banner />
            <BottomBanner />
        </div>
    )
}