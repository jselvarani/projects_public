import React, { useEffect, useState } from 'react'
import styled from 'styled-components'
import { textStyles } from '../../Shared/ReusableStyles'
import { getAllItems } from '../../Services/CRUDServices'
import { CATEGORYJSONURL } from '../../Shared/Constants'
import Subscribe from './Subscribe'
import { FiMail } from 'react-icons/fi'
import { BsFacebook, BsInstagram, BsLinkedin, BsTwitter } from 'react-icons/bs'
import gpay from "../../Assets/images/google-pay.png"
import paypal from "../../Assets/images/paypal.png"
import paytm from "../../Assets/images/paytm.png"
import amazonpay from "../../Assets/images/amazon-pay.png"
import americanexpress from "../../Assets/images/american-express.png"
import applepay from "../../Assets/images/apple-pay.png"

export default function Footer() {
    const [category, setCategory] = useState([])
    useEffect(() => {
        // setCategory(getAllCategory())
        getAllCategory()

    }, [])
    const getAllCategory = () => {
        getAllItems(CATEGORYJSONURL).then(res => setCategory(res.data))
        console.log(category)
    }
    return (
        <Section className='container-fluid bg-dark mt-4 text-start mb-0'>
            <div className='pt-5 ps-5 pb-3 text-white'>
                <h3 className='text-pink pb-3'>OUR CATEGORIES</h3>
                {
                    category && category.map(mainCategory => {
                        return <p key={mainCategory.id} className='text-grey'><span className='fw-bold h5'>{mainCategory.categoryName} : </span>
                            {
                                mainCategory.subCategory && mainCategory.subCategory.map(item => {
                                    return <span key={item.subCategoryName} className='h6 subcat'>{item.subCategoryName} | </span>
                                })
                            }
                        </p>
                    })
                }
            </div>
            <hr className='text-grey' />

            <div className='row text-grey pb-3 mt-2 ps-5'>
                <div className='col-2'>
                    <p className='fw-bold'>HELP</p>
                    <p>Contact Us</p>
                    <p>Delivery Policy</p>
                    <p>Refund Policy</p>
                    <p>Payment Methods</p>
                </div>
                <div className='col-2'>
                    <p className='fw-bold'>ABOUT</p>
                    <p>About Us</p>
                    <p>Store Locators</p>
                    <p>Terms of Service</p>
                    <p>Privacy Policy</p>
                </div>
                <div className='col-2'>
                    <p className='fw-bold'>GET IN TOUCH</p>
                    <p className='h5'><a href="mailto:selva@hcl.com"></a><FiMail className='icon h2 pe-2' /> Email Us</p>
                    <p className='fw-bold'>FOLLOW US</p>
                    <p className='text-white'><span className='h4'><BsFacebook className='icon' /></span>
                        <span className='h4 ps-2 pe-2'><BsInstagram className='icon' /></span>
                        <span className='h4 ps-2 pe-2'><BsLinkedin className='icon' /></span>
                        <span className='h4 ps-2 pe-2'><BsTwitter className='icon' /></span>
                    </p>
                </div>
                <div className='col-2'>
                    <p className='fw-bold'>WE ACCEPT</p>
                    <p className='mb-0'>
                        <span className='payment-span me-3'><img src={paypal} className='payment' /></span>
                        <span className='payment-span'><img src={gpay} className='payment' /></span>
                    </p>
                    <p className='mt-0 mb-0'>
                        <span className='payment-span pe-3 me-2'><img src={amazonpay} className='payment' /></span>
                        <span className='payment-span'><img src={applepay} className='payment' /></span>
                    </p>
                    <p>
                        <span className='pe-3 me-2'><img src={americanexpress} className='payment-big w-25' /></span>
                    </p>
                </div>
                <div className='col-4'>
                    <Subscribe />
                </div>
            </div>
        </Section>
    )
}

export const Section = styled.div`
${textStyles}
.subcat{
    letter-spacing:0.2rem;
}
.icon{
    color:#ff8f9c;
    cursor: pointer;
    &:hover{
        color:white;
        transition: 0.3s ease-in-out;
    }
}
.payment{
    height:40px;
   
}
.payment-span{
    background-color: white;
    padding:5px;
}

`
