import React, { useState } from 'react'
import styled from 'styled-components'
import { btnStyles } from '../../Shared/ReusableStyles'
import { toast } from 'react-toastify'

export default function Subscribe() {

    const [email, setEmail] = useState('')

    const subscribe = () => {
        if (email.length == 0) {
            toast.warn('Email Required')
            return false;
        }
        var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

        if (email.match(validRegex)) {
            toast.success('Subscribed Successfully')
            setEmail('')
            return true;

        } else {
            toast.error('Invalid Email')
            return false;
        }
    }
    return (
        <Section className='text-start pb-3 '>
            <p className='text-grey h4 lh-md pe-3'>Subscribe today and get 10% off </p>
            <p className='text-grey h4 lh-md pe-3 mt-3'>
                On your first purchase </p>
            <div className='mt-5'>
                <input type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className='ps-2 w-50'
                    placeholder='Email Id' />
                <button className='btn btn-pink' onClick={() => subscribe()}>Subscribe</button>
            </div>
        </Section>
    )
}

export const Section = styled.div`
input{
    height:3rem;
    outline: none;
}
button{
    margin-left:0px;
    margin-top:-5px;
    height:3rem;
    border-radius: 0px;
}
${btnStyles}

`
