export const JSONURL = "http://localhost:5000"

export const LOGINJSONURL = `${JSONURL}/login`

export const CATEGORYJSONURL = `${JSONURL}/category`

export const PRODUCTSJSONURL = `${JSONURL}/products`

export const CARTJSONURL = `${JSONURL}/cart`

export const WISHLISTJSONURL = `${JSONURL}/wishlist`

export const ORDERSJSONURL = `${JSONURL}/orders`

export const PROFILEJSONURL = `${JSONURL}/profile`

export const ADDTOCART = 'ADD TO BAG'

export const GOTOCART = 'ADDED TO BAG'

export const ADDTOWISHLIST = 'ADD TO WISHLIST'

export const REMOVEFROMWISHLIST = 'ADDED TO WISHLIST'
