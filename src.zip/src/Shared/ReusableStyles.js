import { css } from 'styled-components'
export const textStyles = css`
.text-pink{
    color:#ff8f9c;
}
.text-grey{
    color:grey;
}
h1{
    font-size: 3rem;
}
`
export const bgStyles = css`
.bg-pink{
    background-color: #ff8f9c;
}
`

export const cursorPointer = css`
.cursorPointer{
    cursor:pointer;
}
`

export const btnStyles = css`
.btn-pink{
    background-color: #ff8f9c;
    color:white;
    font-weight: bold;
    letter-spacing: 0.1rem;
    &:hover{
        background-color: black;
    }
}
.btn-outline-pink{
    border: 1px solid #ff8f9c;
    &:hover{
        background-color: #ff8f9c;
        transition: 0.3s ease-in-out;
    }
}
.btn-inside-icon{
    font-size: 25px;
    margin-top:-3px;
}
`

export const imageZoomEffect = css`
img{
    transition:0.8s ease-in-out;
    &:hover{
        transform:scale(1.2)
    }
}`

