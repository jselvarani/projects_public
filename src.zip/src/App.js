import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header';
import { Routes, Route, useLocation } from 'react-router-dom'
import Products from './Components/Products/Products';
import Home from './Components/Home/Home';
import Footer from './Components/Footer/Footer';
import Product from './Components/Products/Product';
import Login from './Components/Login/Login';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import MyCart from './Components/Products/MyCart';
import Orders from './Components/Reports/Orders';
import Wishlist from './Components/Reports/Wishlist';
import Profile from './Components/Profile/Profile';


function App() {
  const notify = () => toast("Wow so easy!");
  let { pathname } = useLocation()
  const isLogin = pathname === '/login'
  return (
    <div className="App">
      {!isLogin && < Header />}
      <ToastContainer />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="products" element={<Products />} />
        <Route path="cart" element={<MyCart />} />
        <Route path="orders" element={<Orders />} />
        <Route path="wishlist" element={<Wishlist />} />
        <Route path="login" exact element={<Login />} />
        <Route path="profile" exact element={<Profile />} />
        <Route path="product" element={<Product />}>
          <Route path=':id' element={<Product />} />
        </Route>
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
